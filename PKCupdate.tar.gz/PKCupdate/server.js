var PKCport = 50000;
console.log("listning at port [ "+PKCport+" ]");

//require
var fs = require('fs');
var express = require('express');
var socket = require('socket.io');

//rederect server
var app = express();
var PKCclientserver = app.listen(PKCport);
app.use(express.static('PKC/_httprootPKC/public'));
var ioClient = socket(PKCclientserver);
ioClient.sockets.on('connection', clientconnect);

console.log("okay, I'm listning");
var connectionnumber = 0;
var savefile = '';
var trusted = {};

var users = fs.readFileSync("PKC/_httprootPKC/public/users.json");
users = JSON.parse(users);
console.log(users)

var usersnum = 0;
var recordingnum = 1;
var recorderDict = {};
var hrTime;
var curTime;

var PassCheck = {"James-Isaac-Atin-Godden":"27442906e539d679aecbefbb30155c54","Juro-Kim-Feliz":"64a161873beb9d989def0a4ec6996f38","CyArCo":"9dfa571c673d5ad745b1a46ed9fe686c"}

function clientconnect(socket){

  //rederect server events
  connectionnumber++;
  if(connectionnumber < 2){
    savefile = '<b>There is '+connectionnumber+' visitor</b>';
  }else{
    savefile = '<b>There are '+connectionnumber+' visitors</b>';
  }

  fs.writeFile('PKC/_httprootPKC/public/connectionnumber.txt', savefile, function (err) {
    if (err) throw err;
    console.log('Saved!');
  });

  console.log(connectionnumber);
  socket.broadcast.emit('Inform', connectionnumber);
  console.log("New connection [ "+socket.id+" ]");

  //PKC server events
  socket.on('handshake',handshake);
  socket.on('PKCmsg',PKCmsg);
  socket.on('PKCmidi',PKCmidi);
  socket.on('feedback',feedback);
  socket.on('stream',stream);
  console.log("sockets ready");

  //general server events
  socket.on('disconnect', clientLost);

  console.log("broadcast to all");

  //general server functions
  function clientLost() {

    connectionnumber--;
    socket.broadcast.emit('Inform', connectionnumber);
    console.log("connection [ "+socket.id+" ] lost");

    if(trusted[socket.id] !== undefined ) {

      usersnum--;
      socket.broadcast.emit('PKCusers', ['dis',trusted[socket.id]]);
      delete trusted[socket.id];

      if(usersnum == 0){

        fs.writeFile("PKC/_httprootPKC/public/users.json",JSON.stringify({"CyArCo":0,"Juro-Kim-Feliz":0,"James-Isaac-Atin-Godden":0}),
        function(){

          console.log("users info reset");
        });

        fs.writeFile("PKC/_httprootPKC/public/dialog.txt", "", function (err) {
        if (err) throw err;

          console.log('html reset');
        });
      }
    }
  }

  //PKC server functions
  function handshake(data){

    if(users[data[0]] !== undefined && data[1] === PassCheck[data[0]]) {

      if(usersnum < 1){

        recordingnum=1;
        hrTime = process.hrtime()[0] * 1000000 + process.hrtime()[1] / 1000;

        fs.readdirSync("PKC/_httprootPKC/recorde/").forEach(file => {

            recordingnum++
        });
      }

      usersnum++

      trusted[socket.id] = data[0];
      socket.broadcast.emit('PKCusers', ['con',trusted[socket.id]]);
      console.log("PKC client is --- [ "+data[0]+" ] --- "+socket.id);
    }
  }

  function PKCmsg(data){

    if(trusted[socket.id] !== undefined ) {

      data = JSON.parse(data);
      for(var PKCmsgkey in data){
        for (var PKCmsgitem of data[PKCmsgkey]) {

          socket.broadcast.emit("char", [trusted[socket.id],PKCmsgitem]);
          console.log("PKCmsg --- "+PKCmsgitem+" --- by "+trusted[socket.id]);
        }
      }

      curTime = process.hrtime()[0] * 1000000 + process.hrtime()[1] / 1000;

      recorderDict[(curTime-hrTime)] = data;
      fs.writeFile("PKC/_httprootPKC/recorde/rec-"+recordingnum+".json",JSON.stringify(recorderDict),
      function(){

        console.log("recording msg");
      });
    }
  }

  function PKCmidi(data){

    if(trusted[socket.id] !== undefined ) {
      data = JSON.parse(data);

      for(var PKCmidikey in data){

        socket.broadcast.emit("midi", data[PKCmidikey]);
        console.log("PKCmidi ---"+data[PKCmidikey]+"--- ");
      }

      curTime = process.hrtime()[0] * 1000000 + process.hrtime()[1] / 1000;

      recorderDict[(curTime-hrTime)] = data;
      fs.writeFile("PKC/_httprootPKC/recorde/rec-"+recordingnum+".json",JSON.stringify(recorderDict),
      function(){

        console.log("recording midi");
      });
    }
  }

  function feedback(data){

    //console.log(data);
    if(data[0] == "users"){
      fs.writeFile("PKC/_httprootPKC/public/"+data[0]+".json",JSON.stringify(data[1]),
      function(){

        console.log("users info saved");
      });
    }else if(data[0] == "dialog"){
      fs.writeFile("PKC/_httprootPKC/public/"+data[0]+".txt", data[1], function (err) {
      if (err) throw err;

        console.log('html saved!');
      });
    }

  }

  function stream(data){

    var ua = new Uint8Array(data.length);

    Array.prototype.forEach.call(data, function (ch, i) {
      ua[i] = ch.charCodeAt(0);
    });

    console.log(ua);
  }
}
console.log("Project Key Code server ready");
