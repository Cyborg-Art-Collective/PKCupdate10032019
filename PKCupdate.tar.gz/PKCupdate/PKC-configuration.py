#!/usr/bin/env python2

import os, sys
import io
import collections
import json
import ast

awnser = ''
PKCConf = collections.OrderedDict(sorted(json.load(open("./saved-files/PKC-config.json")).items()))

print("\nsettings: ")
print("\n\toverwrite: "+PKCConf["overwrite"]+"\n\n\tThe overwrite function make sure that the previous character in replace when another pattern of keys is found in the same range of a already found pattern(when these key are still down)\n\n")
print("\n\tTime interval: "+str(PKCConf["interval"])+"\n\n\tThe time interval is to prevent double letters caused by the speed with which the program can identify patterns. Without the time interval it might find two chord in some cases because one of the keys was pressed a fraction of a second later.\n\t\t!To deactivate the time interval set the value to zero!\n\t\t!Make sure the decimal point is a point and not a comma!\n\n")

if ast.literal_eval(PKCConf["overwrite"]) == True:
    awnser = raw_input('\n\nDo you want set the overwite function to False(y/n)?')

elif ast.literal_eval(PKCConf["overwrite"]) == False:
    awnser = raw_input('\n\nDo you want set the overwite function to True(y/n)?')

if awnser == 'y' or awnser == 'Y' or awnser == 'yes' or awnser == 'Yes' or awnser == 'YES':

    if ast.literal_eval(PKCConf["overwrite"]) == True:
        PKCConf["overwrite"] = "False"
    elif ast.literal_eval(PKCConf["overwrite"]) == False:
        PKCConf["overwrite"] = "True"

    print("\n\toverwrite is set to:\n\t"+PKCConf["overwrite"])

awnser = raw_input('\n\nDo you want change the time interval(y/n)?')

if awnser == 'y' or awnser == 'Y' or awnser == 'yes' or awnser == 'Yes' or awnser == 'YES':

    intervalVar = input('\tTime interval: ')

    if type(intervalVar) == float or type(intervalVar) == int:
        PKCConf["interval"] = float(intervalVar)
        print("\n\ttime invertal is set to:\n\t"+str(PKCConf["interval"]))
    elif type(intervalVar) != float:
        print("\nthis input in not a number: "+str(type(intervalVar))+"\n\n")

with open('./saved-files/PKC-config.json', 'w') as outfile:
    json.dump(PKCConf, outfile)

print("\n\tsaving file....\n\n")
