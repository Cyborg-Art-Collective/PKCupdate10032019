var socket;
var dialog = {};
var writingline = 0;
var file;
var users;

var dialogfield = {};
var divPositions = {};

function preload(){

  file = loadStrings("connectionnumber.txt");
  users = loadJSON('users.json');

  writingline = 0;
  //socket
  socket = io.connect('http://127.0.0.1:50000')

  //CyArCo
  socket.on('char', Msg);
  socket.on('midi', player);
  socket.on('Inform',Inform);
  socket.on('PKCusers',PKCusers);
}

//----------------------------------------------------------------------------------------------
//setup
//----------------------------------------------------------------------------------------------
//==============================================================================================
function setup() {

  //dialog
  dimentions = {w:windowWidth,h:windowHeight};
  console.log(file);

  //connections
  connectioncount = createDiv(file[0]);
  connectioncount.attribute('id', 'connectioncount');
  connectioncount.parent('header');

}
//----------------------------------------------------------------------------------------------
//make div
//----------------------------------------------------------------------------------------------
//==============================================================================================

function newLine(usr,line,content) {

    dialogfield[str(line)] = createDiv("");
    dialogfield[str(line)].attribute('class', 'line');
    dialogfield[str(line)].parent('dialog');

    if (content.length > 0){
      dialogfield[str(line)].html('<b>'+usr.replace(/-/g, " ")+'</b><br/>'+content);
    }

}

//----------------------------------------------------------------------------------------------
//server events
//----------------------------------------------------------------------------------------------
//==============================================================================================
function Msg(data){
  //console.log(data[0]+" send> "+data[1]);
  if(typeof users[data[0]] !== 'undefined'){

    if(typeof dialog[users[data[0]]] === 'undefined'){
      dialog[users[data[0]]] = "";
    }

    if(data[1] == '[bks]'){

      if(dialog[users[data[0]]].length > 0){
        dialog[users[data[0]]] = dialog[users[data[0]]].slice(0, -1);
      }

    }else if(data[1] == '[ent]'){

      writingline++;
      users[data[0]] = writingline;
      dialog[users[data[0]]] = "";
      feedback(["users",users]);
      console.log('line '+str(writingline)+' - '+dialog[users[data[0]]]);

    }else if(data[1] == '[spc]'){

      dialog[users[data[0]]] += " ";

    }else{
      dialog[users[data[0]]] += data[1];
    }

    if(typeof dialogfield[str(users[data[0]])] !== 'undefined' && dialog[users[data[0]]].length > 0){

      dialogfield[str(users[data[0]])].html('<b>'+data[0].replace(/-/g, " ")+'</b><br/>'+dialog[users[data[0]]]);
      console.log('message - '+data[1]);

    }else if(typeof dialogfield[str(users[data[0]])] === 'undefined' && dialog[users[data[0]]].length > 0){

      newLine(data[0],users[data[0]],dialog[users[data[0]]]);
      console.log('message - '+data[1]);

    }else if(typeof dialogfield[str(users[data[0]])] !== 'undefined'){

      dialogfield[str(users[data[0]])].html('<b>...</b>');

    }

    feedback(["dialog",$('#dialog').html()]);
    htmlIndex();
  }
}

//----------------------------------------------------------------------------------------------
//server connection
//----------------------------------------------------------------------------------------------
//==============================================================================================
function Inform(data){
    console.log(data);
    if(data < 2){
      connectioncount.html('<b>There is '+data+' visitor</b>')
    }else{
      connectioncount.html('<b>There are '+data+' visitors</b>')
    }
}

//user connection
//----------------------------------------------------------------------------------------------
//==============================================================================================
function PKCusers(data){

  if(data[0] == 'con'){

    writingline++;
    users[data[1]] = writingline;
    online(data[1]);

  }else if(data[0] == 'dis'){

    console.log(data[1]+" left the building")
    offline(data[1]);

  }

}

//feedback
//----------------------------------------------------------------------------------------------
//==============================================================================================
function feedback(data){

  socket.emit('feedback', data );

}

//player
//----------------------------------------------------------------------------------------------
//==============================================================================================
function player(data){
  console.log('midi - note '+data[0][1]+' vel '+data[0][2]+' >> '+data);
  MIDI.noteOn(0, data[0][1], data[0][2], data[0][3]);
  MIDI.noteOff(0, data[0][1], data[0][2] + 0.75);
}


function draw() {
}
