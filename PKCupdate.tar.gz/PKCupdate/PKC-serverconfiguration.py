#!/usr/bin/env python2

import os, sys
import io
import collections
import json

serverConf = collections.OrderedDict(sorted(json.load(open("./saved-files/server-config.json")).items()))

print("\nstatus: "+serverConf["status"])
print("\n\tip: "+serverConf[serverConf["status"]]+"\n\ton port: "+serverConf["port"]+"\n\tdomain name[ "+serverConf["domain"]+" ]")
print("\nother option(s)");

for itm in serverConf:
    if itm !=  serverConf["status"] and itm != "domain" and itm != "status" and itm != "port":
        print("\n\t"+itm+" ip: "+serverConf[itm]+"\n\ton port: "+serverConf["port"])

if serverConf["status"] == "remote":
    awnser = raw_input('\n\nDo you want to switch from the '+serverConf["status"]+' \nserver to the local server(y/n)?')
elif serverConf["status"] == "local":
    awnser = raw_input('\n\nDo you want to switch from the '+serverConf["status"]+' \nserver to the remote server(y/n)?')

if awnser == 'y' or awnser == 'Y' or awnser == 'yes' or awnser == 'Yes' or awnser == 'YES':
    if serverConf["status"] == "remote":
        serverConf["status"] = "local"
    elif serverConf["status"] == "local":
        serverConf["status"] = "remote"

    print("\n\tserver is set to:\n\t"+serverConf["status"])

    with open('./saved-files/server-config.json', 'w') as outfile:
        json.dump(serverConf, outfile)
