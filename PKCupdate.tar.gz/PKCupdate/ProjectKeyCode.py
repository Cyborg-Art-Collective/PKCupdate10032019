#!/usr/bin/env python2

import os, sys
import io
import collections
import webbrowser
import subprocess

from datetime import datetime
from socketIO_client import SocketIO, BaseNamespace
import json

import pygame.midi as midi
import pygame

import time
import math

import threading
from thread import *

class Tee(object):
    def __init__(self, *files):
        self.files = files
    def write(self, obj):
        for f in self.files:
            f.write(obj)
            f.flush() # If you want the output to be visible immediately
    def flush(self) :
        for f in self.files:
            f.flush()

f = open('./log-files/run-Log.txt', 'a')
original = sys.stdout
sys.stdout = Tee(sys.stdout, f)

PKCmsg = ''
PKCmidi= ''
lastMsgTime = 0
lastMsg = ''
senddata = ''
capslock = False


def openBrowser(ip,port):
    if severConf["status"] == "local":
        url = "http://"+ip+":"+port
    elif severConf["status"] == "remote":
        url = "http://"+ip

    webbrowser.open_new_tab(url)

severConf = collections.OrderedDict(sorted(json.load(open("./saved-files/server-config.json")).items()))

def startNodejs():
    subprocess.call('node PKC/_httprootPKC/server.js', shell=True)

if severConf["status"] == "local":
    try:
        startNodejsthread = threading.Thread(target=startNodejs)
        startNodejsthread.daemon = True
        startNodejsthread.start()
    except:
        print('server already running')

#------------------------------------------------------------------------------
#==============================================================================
#		Timer
#==============================================================================

print ('--------------------------------------------------------')
print ('Starting PKC interface')
print ('========================================================')
print ('--------------------------------------------------------')

timerStart = time.time()
print ('Start timer ___ '+str(time.time()-timerStart)+' ___ ')

#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		Virtual Keyboard
#==============================================================================

class VirKey:

	KeyCount = 141

	try:
		len(VirtualKeyboard)

	except KeyboardInterrupt:
		try:
			sys.exit(0)
		except SystemExit:
			os._exit(0)

	except:

		print ('--------------------------------------------------------')
		print ('Mapping keyboard')
		print ('========================================================')
		print ('--------------------------------------------------------')

		VirtualKeyboard = dict()
		Offset = 0
		Keypath = ['C','C#-Db','D','D#-Eb','E','F','F#-Gb','G','G#-Ab','A','A#-Bb','B']

        for i in range(-13,0):

            VirtualKeyboard.update({i:['none',False]})

        for i in range(Offset,KeyCount):

			if i-Offset >= len(Keypath):
				Offset += len(Keypath)

			VirtualKeyboard.update({i:[Keypath[(i-Offset)],False]})

with open('./saved-files/virtual_keyboard.json', 'w') as outfile:
	json.dump(VirKey.VirtualKeyboard, outfile)

print (VirKey.VirtualKeyboard)
print ('--------------------------------------------------------')
print ('--------------------------------------------------------')

#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		Chord list
#==============================================================================

class Chords:

    print ('--------------------------------------------------------')
    print ('Chords')
    print ('========================================================')
    print ('--------------------------------------------------------')

    ChordsDict = {'Power chord':[(1,False),(2,False),(3,False),(4,False),(5,False),(6,False),(7,True),(8,False),(9,False),(10,False),(11,False),(12,False)],'Octave': [(1,False) ,(2,False),(3,False),(4,False),(5,False),(6,False),(7,False),(8,False),(9,False),(10,False),(11,False),(12,True)],'Suspended2': [(1,False),(2,True),(3,False),(4,False),(5,False),(6,False),(7,True),(8,False),(9,False),(10,False),(11,False),(12,False)],'Suspended4': [(1,False),(2,False),(3,False),(4,False),(5,True), (6,False),(7,True),(8,False),(9,False),(10,False),(11,False),(12,False)],'Major': [(1,False),(2,False),(3,False),(4,True),(5,False),(6,False),(7,True),(8,False),(9,False),(10,False),(11,False),(12,False)],'Minor': [(1,False),(2,False),(3,True),(4,False),(5,False),(6,False),(7,True),(8,False),(9,False),(10,False),(11,False),(12,False)],'Seventh': [(1,False),(2,False),(3,False),(4,True),(5,False),(6,False),(7,True),(8,False),(9,False),(10,True),(11,False),(12,False)],'Augmented': [(1,False) ,(2,False),(3,False),(4,True),(5,False),(6,False),(7,False),(8,True),(9,False),(10,False),(11,False),(12,False)],'Diminished': [(-4,False),(1,False),(2,False),(3,True),(4,False),(5,False),(6,True),(7,False),(8,False),(9,False),(10,False),(11,False),(12,False)]}

    SpecialNotes = {'!':[36,48,84,96],"'":[95],",":[94],'?':[93],'.':[40],'[bks]':[82,80]}
    SequanceNotes = {36:[40,'[spc]'],40:[36,'[spc]'],47:[43,'[ent]'],43:[47,'[ent]']}

    print ('Power chord - ',ChordsDict['Power chord'])
    print ('Octave - ',ChordsDict['Octave'])
    print ('Suspended2 - ',ChordsDict['Suspended2'])
    print ('Suspended4 - ',ChordsDict['Suspended4'])
    print ('Major - ',ChordsDict['Major'])
    print ('Minor - ',ChordsDict['Minor'])
    print ('Seventh - ',ChordsDict['Seventh'])
    print ('Augmented - ',ChordsDict['Augmented'])
    print ('Diminished - ',ChordsDict['Diminished'])
    print ('--------------------------------------------------------')
    print ('--------------------------------------------------------')

#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		Alphabet
#==============================================================================

class Alphabet:
	try:

		if not os.path.exists("./saved-files"): os.makedirs("./saved-files")
		Passport =  collections.OrderedDict(sorted(json.load(open("./saved-files/Passport.txt")).items()))
		User = Passport['name']


	except:

		Passport = {'name':'anonymous','password':''}
		User = Passport['name']

	print ('Getting files for '+User)
	json.dump(Passport, open("./saved-files/Passport.txt",'w'), sort_keys=True)
	subdirectory = str("./saved-files/"+User+ "-dict")

	try:

		print ('--------------------------------------------------------')
		print ('Loading alphabet')
		print ('========================================================')
		print ('--------------------------------------------------------')

		AlphabetList =  collections.OrderedDict(sorted(json.load(open(str(subdirectory+"/Alphabet.txt"))).items()))
		for key in AlphabetList:

			print (key+' - '+AlphabetList[key])

	except KeyboardInterrupt:

		try:
			sys.exit(0)
		except SystemExit:
			os._exit(0)

	except Exception:
		print ('Loading failed [no such file or directory]')
		print ('--------------------------------------------------------')
		print ('composing alphabet')
		print ('========================================================')
		print ('--------------------------------------------------------')

		if not os.path.exists(subdirectory): os.makedirs(subdirectory)

		AlphabetList = {"A Augmented": "[cap]", "A Diminished": "q", "A Major": "z", "A Minor": "z", "A Octave": "n","A Power chord": "z", "A Seventh": "z", "A Suspended2": "a", "A Suspended4": "a", "A#-Bb Augmented": "[empty]", "A#-Bb Diminished": "[empty]", "A#-Bb Major": "h", "A#-Bb Minor": "h", "A#-Bb Octave": "x", "A#-Bb Power chord": "h", "A#-Bb Seventh": "h", "A#-Bb Suspended2": "u", "A#-Bb Suspended4": "u", "B Augmented": "[empty]", "B Diminished": "[empty]", "B Major": "b", "B Minor": "b", "B Octave": "p", "B Power chord": "b", "B Seventh": "b", "B Suspended2": "i", "B Suspended4": "i", "C Augmented": "[empty]", "C Diminished": "[empty]", "C Major": "c", "C Minor": "c", "C Octave": "r", "C Power chord": "c", "C Seventh": "c", "C Suspended2": "[empty]", "C Suspended4": "[empty]", "C#-Db Augmented": "[empty]", "C#-Db Diminished": "[empty]", "C#-Db Major": "j", "C#-Db Minor": "j", "C#-Db Octave": "y", "C#-Db Power chord": "j", "C#-Db Seventh": "j", "C#-Db Suspended2": "[empty]", "C#-Db Suspended4": "[empty]", "D Augmented": "[empty]", "D Diminished": "[empty]", "D Major": "d", "D Minor": "d", "D Octave": "s", "D Power chord": "d", "D Seventh": "d", "D Suspended2": "[empty]", "D Suspended4": "[empty]", "D#-Eb Augmented": "[empty]", "D#-Eb Diminished": "[empty]", "D#-Eb Major": "k", "D#-Eb Minor": "k", "D#-Eb Octave": "[empty]", "D#-Eb Power chord": "k", "D#-Eb Seventh": "k", "D#-Eb Suspended2": "[empty]", "D#-Eb Suspended4": "[empty]", "E Augmented": "[empty]", "E Diminished": "[empty]", "E Major": "[empty]", "E Minor": "[empty]", "E Octave": "t", "E Power chord": "[empty]", "E Seventh": "[empty]", "E Suspended2": "e", "E Suspended4": "e", "F Augmented": "[empty]", "F Diminished": "[empty]", "F Major": "f", "F Minor": "f", "F Octave": "v", "F Power chord": "f", "F Seventh": "f", "F Suspended2": "[empty]", "F Suspended4": "[empty]", "F#-Gb Augmented": "[empty]", "F#-Gb Diminished": "[empty]", "F#-Gb Major": "l", "F#-Gb Minor": "l", "F#-Gb Octave": "[empty]", "F#-Gb Power chord": "l", "F#-Gb Seventh": "l", "F#-Gb Suspended2": "[empty]", "F#-Gb Suspended4": "[empty]", "G Augmented": "[empty]", "G Diminished": "[empty]", "G Major": "g", "G Minor": "g", "G Octave": "w", "G Power chord": "g", "G Seventh": "g", "G Suspended2": "o", "G Suspended4": "o", "G#-Ab Augmented": "[empty]", "G#-Ab Diminished": "[empty]", "G#-Ab Major": "m", "G#-Ab Minor": "m", "G#-Ab Octave": "[empty]", "G#-Ab Power chord": "m", "G#-Ab Seventh": "m", "G#-Ab Suspended2": "[empty]", "G#-Ab Suspended4": "[empty]"}
		json.dump(AlphabetList, open(str(subdirectory+"/Alphabet.txt"),'w'),sort_keys=True)

	print ('--------------------------------------------------------')
	print ('--------------------------------------------------------')

#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		Pathern check
#==============================================================================

class Keythread:
	chordThread = {}
	for i in range(-13,141):
		chordThread.update({i:''})
	print ('Keythread ',chordThread);

#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		Pathern check
#==============================================================================

noteLog = []
pathernBuffer = {}

def check(TimeOfRequest):

    def checkchords(noteCH,TimeOfRequest):
        global keyBuffer
        global pathernBuffer
        global playtimeinterval
        loopBreak = False
        print_lock = threading.Lock()


        for special in Chords.SpecialNotes:

            loopBreak = False
            for specialNoteCheck in Chords.SpecialNotes[special]:

                if noteCH in Chords.SpecialNotes[special] and VirKey.VirtualKeyboard[specialNoteCheck][1] == True:
                    pass
                else:
                    loopBreak = True
                    break

            if loopBreak:
                notePattern = ''
            else:

                if noteCH in pathernBuffer:
                    del pathernBuffer[noteCH]
                    overwrite = True;
                else:
                    overwrite = False;

                keyBuffer = 0
                notePattern = special

                with print_lock:

                    sendMsg(str(notePattern),TimeOfRequest,overwrite)

                break

        for Pattern in Chords.ChordsDict:

            loopBreak = False
            for checkPattern in Chords.ChordsDict[Pattern]:

                if VirKey.VirtualKeyboard[(noteCH+checkPattern[0])][1] == checkPattern[1]:

                    pass

                else:

                    loopBreak = True
                    break

            if loopBreak:

                notePattern = ''

            else:

                keyBuffer = 0
                notePattern = str(VirKey.VirtualKeyboard[noteCH][0]+' '+Pattern)

                if noteCH in pathernBuffer:
                    del pathernBuffer[noteCH]
                    overwrite = True;
                else:
                    overwrite = False;

                pathernBuffer[noteCH] = notePattern

                with print_lock:

                    sendMsg(str(Alphabet.AlphabetList[notePattern]),TimeOfRequest,overwrite)

                break

    for i in noteLog:

        Keythread.chordThread[i] = threading.Thread(target=checkchords, args=(i,TimeOfRequest))
        Keythread.chordThread[i].daemon = True
        Keythread.chordThread[i].start()

#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		MIDI
#==============================================================================

pygame.init()
pygame.fastevent.init()
midi.init()

print ('--------------------------------------------------------')
print ('MIDI input output')
print ('========================================================')
print ('--------------------------------------------------------')
print("Default input device is: ")
print ('Default input:',midi.get_default_input_id())
print ('Default output:',midi.get_default_output_id(),'\n')

for i in range(midi.get_count()):

	print (midi.get_device_info(i));

#		Set input
#==============================================================================

try:

	keyboardConf = collections.OrderedDict(sorted(json.load(open("./saved-files/keyboard.json")).items()))
	ipDev = keyboardConf['in']
	opDev = keyboardConf['out']

except:

	print(' !!! WARNING !!! no keyboard configuration file found')
	ipDev = midi.get_default_input_id()
	opDev = midi.get_default_output_id()

x = midi.Input(ipDev,0)

class getX:
	def __getitem__(self,index):
		print (x)

x.read(1)
print(midi.get_device_info(ipDev))

#		Set output
#==============================================================================

player = midi.Output(opDev,0)
player.set_instrument(1,1)
print(midi.get_device_info(opDev))

print ('--------------------------------------------------------')
print ('--------------------------------------------------------')

print ('--------------------------------------------------------')
print ('MIDI')
print ('========================================================')
print ('--------------------------------------------------------')

#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		Server connect
#==============================================================================

try:
    def PKCserver():
        global PKCmsg
        global PKCmidi
        ip = severConf[severConf["status"]]
        port = severConf["port"]
        class Namespace(BaseNamespace):

            def on_connect(self):
                print ('Handshake between server and '+str(Alphabet.User))
                socketIO.emit('handshake', [Alphabet.User,Alphabet.Passport['password']])
                print (' --- Server connected --- ')
                openBrowser(ip,port)
            def on_disconnect(self):
                print('disconnect')
            def on_reconnect(self):
                print('reconnect')

        socketIO = SocketIO('http://'+ip, port, Namespace )
        socketIO.wait(seconds = 1)

        while True:

            if PKCmsg != '':

                socketIO.emit('PKCmsg', PKCmsg)
                PKCmsg = ''

            if PKCmidi != '':

                socketIO.emit('PKCmidi', PKCmidi)
                PKCmidi = ''

    Serverthread = threading.Thread(target=PKCserver)
    Serverthread.daemon = True
    Serverthread.start()

except KeyboardInterrupt:

	try:
		sys.exit(0)
	except SystemExit:
		os._exit(0)

except serverError as err:

	print (' --- '+err+' --- ')

except:

	print (' --- No server --- ')

#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		Send message
#==============================================================================
playtimeinterval = (time.time());
def sendMsg(msg,TimeOfRequest,overwrite):

    global PKCmsg
    global capslock
    global senddata
    global lastMsgTime
    global lastMsg
    global playtimeinterval

    interval = 0.05

    if msg == '[cap]' and capslock == False:

        capslock = True

    elif msg == '[cap]' and capslock == True:

        capslock = False

    elif msg == '[empty]' or msg == '':

        senddata = ''

    elif capslock == True and len(msg) == 1:

        senddata = msg.upper()

    else:

        senddata = msg

    if msg == '!' and lastMsg == 'r' and (TimeOfRequest-lastMsgTime) <= interval:

        senddata = '[bks]","'+senddata

    elif msg == 'r' and lastMsg == '!' and (TimeOfRequest-lastMsgTime) <= interval:

        senddata = ''

    elif overwrite == True and len(msg) == 1 or (TimeOfRequest-lastMsgTime) <= interval and len(msg) == 1:

        senddata = '[bks]","'+senddata

    PKCmsg = '{"'+Alphabet.User+'":["'+senddata+'"]}'

    print ('[ '+str(time.time()-playtimeinterval)+' ]\t'+PKCmsg)
    playtimeinterval = (time.time());
    lastMsg = msg
    lastMsgTime = TimeOfRequest;

print ('--------------------------------------------------------')
print ('interface ready at --- '+str(time.time()-timerStart)+' --- ')
print ('--------------------------------------------------------')
print ('Press ESC to quit the program')
print ('========================================================')
print ('--------------------------------------------------------')
print ('')
#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		cleanup
#==============================================================================
def clearup():

    global keyBuffer

    for itm in noteLog:
        VirKey.VirtualKeyboard[itm][1] = False

    del noteLog[:]
    pathernBuffer.clear()
    keyBuffer = 0


#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		Interface
#==============================================================================

keyBuffer = 0
Dialog = True
timeinterval = (time.time())

while Dialog == True:

    if x.poll():

        midiEvent = x.read(1)[0]
        noteSW = midiEvent[0][0]
        note = midiEvent[0][1]
        vel = midiEvent[0][2]

        if vel != 0 and note >= 0 and note <= 128:

            timeinterval = (time.time());

            if VirKey.VirtualKeyboard[note][1] == False:

                print('\nevent '+str(midiEvent))
                PKCmidi = '{"'+Alphabet.User+'":'+str(midiEvent)+'}'
                VirKey.VirtualKeyboard[note][1] = True
                noteLog.append(note)

                for i in noteLog:
                    print('\t'+str(i)+' [ '+str(VirKey.VirtualKeyboard[i][0])+' ]')

                if note in Chords.SequanceNotes and keyBuffer == 0:

                    keyBuffer = note
                    check(time.time())

                elif keyBuffer != 0 and note != Chords.SequanceNotes[keyBuffer][0]:

                    keyBuffer = 0
                    check(time.time())

                elif keyBuffer != 0 and note == Chords.SequanceNotes[keyBuffer][0]:

                    notePattern = Chords.SequanceNotes[keyBuffer][1]
                    sendMsg(str(notePattern),(time.time()),False)
                    keyBuffer = 0

                else:

                    check(time.time())

        elif note != 0 and note >= 0 and note <= 128:

            if VirKey.VirtualKeyboard[note][1] == True:

                PKCmidi = '{"'+Alphabet.User+'":'+str(midiEvent)+'}'
                VirKey.VirtualKeyboard[note][1] = False

                try:
                    noteLog.remove(note)
                except:
                    print (str(note)+' not in log')

                if note in pathernBuffer:
                    del pathernBuffer[note]

        if (time.time()-timeinterval) > 0.5 or len(noteLog) > 10:

            timeinterval = (time.time());
            clearup()
#------------------------------------------------------------------------------
#==============================================================================
player.abort()
player.close()
x.close()
midi.quit()
pygame.quit()
